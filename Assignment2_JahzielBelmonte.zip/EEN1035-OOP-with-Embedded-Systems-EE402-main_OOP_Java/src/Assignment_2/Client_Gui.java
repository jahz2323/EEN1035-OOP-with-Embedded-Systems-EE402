package Assignment_2;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener; 


public class Client_Gui extends Frame implements ActionListener, WindowListener {

	public class Client_Canvas extends Canvas{
		private Canvas API_Canvas; 
		private int width,height; 
		public Client_Canvas(int width,int height) {
			this.API_Canvas = new Canvas();
			this.API_Canvas.setSize(width,height);
			this.width = width; 
			this.height = height; 
			this.update(); 
		}
		public void update() {
			this.repaint();
		}
		public void paint(Graphics g) {
			//draw methods 
		}
	
	}
	public class Sound_Level_GUI {
		private TextField Sound_level; 
		public Sound_Level_GUI() {
			super(); 
			this.Sound_level = new TextField(); 
			API_Sound(this.Sound_level); 
		}
		public TextField API_Sound(TextField Sound_Level){
			return Sound_Level; 
		}
	}
	private TextField values,Start_Random;
	private List API_List; 
	private Button Generate; 
	private Panel p; 
	
	private Client_Canvas API_Canvas;  
	private int width = 600; 
	private int height = 600; 
	public Client_Gui(String Sensor_Type) {
		super("Client_Gui"); 
		this.setLayout(new BorderLayout());
		//init - add all components 
		//if certain sensor chosen - switch GUI elements and use specific state from obj class
	}
	public void init() {
		API_Canvas = new Client_Canvas(width,height); 
		this.p = new Panel(new FlowLayout()); 
		this.values = new TextField(); 
		//TextField API_Type = new TextField(); 
		this.Start_Random = new TextField();
		this.Generate = new Button(); 
		API_Listing(); 
		
		p.add(this.API_Canvas);
		p.add(this.values); 
		p.add(this.Start_Random); 
		p.add(this.Generate); 
		p.add(this.API_List); 
		this.add(p);
		this.setVisible(true);
		this.setSize(1000,800);
	}
	public void API_Listing() {
		API_List.add("Sound Level");
		API_List.add("Temperature Level");
		API_List.add("Light Level Level");
	}
	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	public static void main(String args[]) {
		String Sound_Level = "Sound Level"; 
		new Client_Gui(Sound_Level);
	}
}
