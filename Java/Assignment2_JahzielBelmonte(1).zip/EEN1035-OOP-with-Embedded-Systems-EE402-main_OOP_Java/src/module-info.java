/**
 * 
 */
/**
 * 
 */
module OOP_Java {
	requires java.desktop;
}