package App;

public class Student {
	private String name; 
	private int id_num;
	private int telephone; 
	private boolean sex; 
	private String address; 
	public Student(String name, int id_number, int telephone_num,boolean sex_, String addr_ ) {
		this.name = name;
		this.id_num= id_number; 
		this.telephone = telephone_num; 
		this.sex= sex_; 
		this.address = addr_; 
	}
	public void display () { 
		
	}
}
