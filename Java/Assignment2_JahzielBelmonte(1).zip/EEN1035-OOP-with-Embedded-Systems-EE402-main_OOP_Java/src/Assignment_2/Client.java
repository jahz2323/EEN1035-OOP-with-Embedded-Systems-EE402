package Assignment_2;

import java.net.*;
import java.io.*;

public class Client {
	// keep track of Client count & Number of threads for applications should match
	// 3-3
//	private static int Client_Instances = 0;
	protected static String Server_Address;
	private static int portNumber = 3000;
	private Socket socket = null;
	private ObjectOutputStream os = null;
	private ObjectInputStream is = null;

	// the constructor expects the IP address of the server - the port is fixed
	public Client(String[] args) {
		Server_Address = args[0];
		if (!connectToServer(args[0])) {
			System.out.println("XX. Failed to open socket connection to: " + args[0]);
		}
	}

	// modify to connect to ThreadConnectionhandler
	private boolean connectToServer(String serverIP) {
		try { // open a new socket to the server
			this.socket = new Socket(serverIP, portNumber);
			this.os = new ObjectOutputStream(this.socket.getOutputStream());
			this.is = new ObjectInputStream(this.socket.getInputStream());
			System.out.println("00. -> Connected to Server:" + this.socket.getInetAddress() + " on port: "
					+ this.socket.getPort());
			System.out.println("    -> from local address: " + this.socket.getLocalAddress() + " and port: "
					+ this.socket.getLocalPort());
		} catch (Exception e) {
			System.out.println("XX. Failed to Connect to the Server at port: " + portNumber);
			System.out.println("    Exception: " + e.toString());
			return false;
		}
		return true;
	}

	private void POST(Client_Gui gui) {
		while (gui.running) {
			Server_Client_Object API_Data = gui.API_service();
			Object s = (Object) API_Data; 
			Object r = new Object(); 
			Server_Client_Object GET_Data;
			System.out.println("ServerIP: '" + API_Data.get_Address() + "' Values: '" + API_Data.get_values()
			+ "' API_Type: '" + API_Data.get_API_Type());; 
			System.out.println("01. -> Sending obj (" + s + ") to the server...");
			this.send(s);
			try {
				r = receive();
				GET_Data = (Server_Client_Object) r; 
				System.out.println("05. <- The Server responded with: ");
				System.out.println("    <- " + GET_Data);
				System.out.print("Address" + GET_Data.get_Address());
				System.out.print(" API Value" + GET_Data.get_values());
				System.out.print(" API Type" + GET_Data.get_API_Type());
				Thread.sleep(5000);
			} catch (Exception e) {
				System.out.println("XX. There was an invalid object sent back from the server");
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		
		System.out.println("06. -- Disconnected from Server.");
		
	}

	// method to send a generic object.
	private void send(Object o) {
		try {
			System.out.println("02. -> Sending an object...");
			os.writeObject(o);
			os.flush();
		} catch (Exception e) {
			System.out.println("XX. Exception Occurred on Sending:" + e.toString());
		}
	}

	// method to receive a generic object.
	private Object receive() {
		Object o = null;
		System.out.println("02. -> Object sent successfully.");
		try {
			System.out.println("03. -- About to receive an object...");
			o = is.readObject();
			System.out.println("04. <- Object received...");
		} catch (Exception e) {
			System.out.println("XX. Exception Occurred on Receiving:" + e.toString());
		}
		return o;
	}

	protected static String get_Client_Instances() {
		return Server_Address;
	}

	public static void main(String args[]) {

		// String hardcode_addr = String.valueOf(portNumber);
		System.out.println("Java Client - EEN1035 Jahziel Angelo Belmonte ");
		System.out.println("CLient Application started... ");
		if (args.length == 3) {
			// need to create server_client obj to send
			Client theApp = new Client(args);
			Client_Gui gui = new Client_Gui(theApp, args[1], args[2]);
			try {
				theApp.POST(gui);

			} catch (Exception e) {
				System.out.println("Unable to generate GUI");
			}
		} else {
			System.out.println("Error: you must provide the address of the server");
			System.out.println("Usage is:  java Client x.x.x.x  (e.g. java Client 192.168.7.2)");
			System.out.println("      or:  java Client hostname (e.g. java Client localhost)");
		}
		System.out.println("**. End of Application.");
	}
}