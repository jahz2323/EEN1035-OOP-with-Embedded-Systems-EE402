package Assignment_2;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class ServerGUI_Canvas extends Canvas {
	private Image image;

	public ServerGUI_Canvas(int width, int height) {
		this.setSize(width, height);
		this.setBackground(Color.GRAY);
	}

	public void setImage(Image image) {
		this.image = image;
		this.repaint();
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		if (image != null) {
			int x = (getWidth() - image.getWidth(this)) / 4;
			int y = (getHeight() - image.getHeight(this)) / 4;
			g.drawImage(image, x, y, this);
		}
	}

}