package Assignment_2;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/*
 * 	
//	private class Service_object{
//		
//	}
	
	private Calendar calendar;

	// constructor creates the Calendar object, could use the constructor:
	// Calendar(TimeZone zone, Locale aLocale) to explicitly specify
	// the time zone and locale
	public Server_Client_Object() {
		this.calendar = Calendar.getInstance();
	}

	// method returns date/time as a formatted String object
	public String getDateAndTime() {
		Date d = this.calendar.getTime();
		return "The BeagleBone time is: " + d.toString();
	}
 */

@SuppressWarnings("serial")
public class Server_Client_Object extends Object implements Serializable {
	private  String serverIP;
	private  int values;
	private  String API_Type;

	public Server_Client_Object(String data1, int data2, String data3) {
		this.serverIP = data1;
		try {
			this.values = data2;
		} catch (NumberFormatException ex) {
			ex.printStackTrace();
		}
		this.API_Type = data3;
	}

	public String get_Address() {
		return this.serverIP;
	}

	public int get_values() {
		return this.values;
	}

	public String get_API_Type() {
		return this.API_Type;
	}

	public boolean equalsIgnoreCase(String string) {
		// TODO Auto-generated method stub
		return false;
	}

}