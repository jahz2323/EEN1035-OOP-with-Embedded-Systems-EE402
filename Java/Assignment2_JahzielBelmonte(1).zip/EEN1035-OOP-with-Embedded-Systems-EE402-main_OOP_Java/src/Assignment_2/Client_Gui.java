package Assignment_2;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;

public class Client_Gui extends Frame implements ActionListener, WindowListener, AdjustmentListener, ItemListener, MouseListener{
	
	public class Client_Canvas extends Canvas {
		private Image image;

		public Client_Canvas(int width, int height) {
			this.setSize(width, height);
			this.setBackground(Color.GRAY);
		}

		public void setImage(Image image) {
			this.image = image;
			this.repaint();
		}

		@Override
		public void paint(Graphics g) {
			super.paint(g);
			if (image != null) {
				int x = (getWidth() - image.getWidth(this)) / 4;
				int y = (getHeight() - image.getHeight(this)) / 4;
				g.drawImage(image, x, y, this);
			}
		}

	}

//	public class Sound_Level_GUI {
//		private TextField Sound_level;
//
//		public Sound_Level_GUI() {
//			super();
//			this.Sound_level = new TextField();
//			API_Sound(this.Sound_level);
//		}
//
//		public TextField API_Sound(TextField Sound_Level) {
//			return Sound_Level;
//		}
//	}
	private String Address;
	private TextField Noise_TextField, Scroll_Generate;
	private List API_List;
	private Scrollbar scrollbar;
	private Button resetButton;
	private Panel Scroll_Generate_Panel;
	private Panel Canvas_Panel;
	private Label API_Switch, Address_Label, NoiseLabel;
	private String API_Name; 
	private Client app;
	private Client_Canvas API_Canvas;
	private int width = 400;
	private int height = 400;
	protected boolean running;
	//Name "Sound,Temp,Light 
	public Client_Gui(Client _app, String Name, String Level) {
		super("Client_Gui");
		this.running = true; 
		this.setLayout(new FlowLayout());
		this.app = _app;
		// init - add all components
		// if certain sensor chosen - switch GUI elements and use specific state from
 
		// in format : "Name level"
		this.API_Name = Name +" "+Level; 
		
		
		this.Address = Client.get_Client_Instances();		
		this.addWindowListener(this);
		init();
	}

	public void init() {
		this.API_Canvas = new Client_Canvas(width, height);
		this.Scroll_Generate_Panel = new Panel(new BorderLayout());
		this.Canvas_Panel = new Panel(new BorderLayout());
		this.Noise_TextField = new TextField();

		// TextField API_Type = new TextField();
		this.Scroll_Generate = new TextField();
		this.scrollbar = new Scrollbar(Scrollbar.HORIZONTAL, 0, 10, 0, 110);
		this.resetButton = new Button("Reset");
		this.API_List = new List();
		this.API_Switch = new Label();
		this.Address_Label = new Label();
		this.NoiseLabel = new Label(); 

		KeyListener keyListener = new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!((c >= '0') && (c <= '9') || (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE) || c == KeyEvent.VK_ENTER)) {
					getToolkit().beep();
					e.consume();
				}
			}
		};
		
		this.Noise_TextField.addKeyListener(keyListener);
		this.Noise_TextField.addActionListener(this);
		this.Noise_TextField.addMouseListener(this);
		this.resetButton.addActionListener(this);
		this.API_List.addActionListener(this);
		this.scrollbar.addAdjustmentListener(this);

		API_Listing();
		init_DisplayText();

		this.add(this.Noise_TextField);
		this.add(this.NoiseLabel);
		Scroll_Generate_Panel.add(this.Scroll_Generate, BorderLayout.WEST);
		Scroll_Generate_Panel.add(this.scrollbar, BorderLayout.SOUTH);
		Scroll_Generate_Panel.add(this.resetButton, BorderLayout.EAST);
		Scroll_Generate_Panel.add(this.Address_Label, BorderLayout.NORTH);
		

		Canvas_Panel.add(this.API_Switch, BorderLayout.PAGE_START);
		Canvas_Panel.add(this.API_List, BorderLayout.CENTER);
		Canvas_Panel.add(this.API_Canvas, BorderLayout.PAGE_END);

		this.add(Scroll_Generate_Panel);
		this.add(Canvas_Panel);
		this.add(API_Canvas);
		UpdateDisplay();
		this.setVisible(true);
		this.setSize(width, height + 100);
	}

	public void UpdateDisplay() {
		API_Switch.setText("Current application: " + API_Name);
		Image image = null;
		try {
			switch (API_Name) {
			//change for dir 
			case "Sound Level":
				image = ImageIO.read(new File(
						"C:\\Users\\jahziel belmonte\\Downloads\\EEN1035-OOP-with-Embedded-Systems-EE402-main\\EEN1035-OOP-with-Embedded-Systems-EE402-main_OOP_Java\\src\\Assignment_2\\IMAGES\\audio-speaker-left-side-testing.255x256.png"));
				break;

			case "Light Level":
				image = ImageIO.read(new File(
						"C:\\Users\\jahziel belmonte\\Downloads\\EEN1035-OOP-with-Embedded-Systems-EE402-main\\EEN1035-OOP-with-Embedded-Systems-EE402-main_OOP_Java\\src\\Assignment_2\\IMAGES\\lightbulb.256x244.png"));
				break;
			case "Temperature Level":
				image = ImageIO.read(new File(
						"C:\\Users\\jahziel belmonte\\Downloads\\EEN1035-OOP-with-Embedded-Systems-EE402-main\\EEN1035-OOP-with-Embedded-Systems-EE402-main_OOP_Java\\src\\Assignment_2\\IMAGES\\temperature.png"));

				break;
			}
			// System.out.println("Image loaded successfully for: " + API_Name);
		} catch (IOException e) {
			// System.out.println("Error loading image for: " + API_Name);
			// e.printStackTrace();
		}
		API_Canvas.setImage(image);
	}

	public void init_DisplayText() {
		this.Noise_TextField.setText("Input values here...");
		this.Scroll_Generate.setText("Scrollbar value:" + scrollbar.getValue());
		this.API_Switch.setText("Current application: " + this.API_Name);
		this.Address_Label.setText("Connected to:" + Address + "/");
		this.NoiseLabel.setText("Input for Noise here!!"); 
	}

	public void API_Listing() {
		API_List.add("Sound Level");
		API_List.add("Temperature Level");
		API_List.add("Light Level");
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		this.running = false; 
		System.out.println("Window closing");
		System.out.println("Shutting down Sensor...");
		dispose();

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == resetButton) {
			System.out.println("Reset button clicked");
			scrollbar.setValue(0);
			this.Scroll_Generate.setText("Scrollbar value: " + scrollbar.getValue());
			// Add your action logic here
			
		} else if (e.getSource() == API_List || e.getSource() == scrollbar) {
			// System.out.println("List item double-clicked or Enter pressed: " +
			// API_List.getSelectedItem());
			// Add your action logic here
			API_Name = API_List.getSelectedItem();
			UpdateDisplay();
		
		} else if (e.getSource() == Noise_TextField) {
			try {
				//
				int value = Integer.parseInt(Noise_TextField.getText());
				this.NoiseLabel.setText("Sending Noise value: " + value);
				this.Scroll_Generate.setText("Scrollbar value:" + scrollbar.getValue());
				scrollbar.setValue(value);
				Noise_TextField.setText("");
			} catch (NumberFormatException ex) {
				// Handle invalid input
			}
		}
	}

	@Override
	public void adjustmentValueChanged(AdjustmentEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == scrollbar) {
			Scroll_Generate.setText("Scrollbar value: " + scrollbar.getValue());
			UpdateDisplay();
		}

	}

	@Override
	public void itemStateChanged(ItemEvent e) {
//		 TODO Auto-generated method stub
		if (e.getSource() == API_List) {
			if (e.getStateChange() == ItemEvent.SELECTED) {
				System.out.println("List item selected: " + API_List.getSelectedItem());
			}
		}

	}

	public static void main(String args[]) {

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		//If noise component is clicked - clear the textfield 
		if(e.getSource() == this.Noise_TextField) {
			this.NoiseLabel.setText("Sending Noise value of..");
			this.Noise_TextField.setText("");
		}
		UpdateDisplay();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.Noise_TextField) {
			this.Noise_TextField.setText("");
			this.NoiseLabel.setText("Sending Noise value of..");
		}
		UpdateDisplay();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	//important - sending Object from client to Server
	/*
	 * POST 
	 * Address as String
	 * Sensor value as int 
	 * API Type as String
	 */
	protected Server_Client_Object API_service() {
		String data1 = this.Address;
		int data2 = scrollbar.getValue();
		String data3 = this.API_Switch.getText();
		Server_Client_Object API_Data = new Server_Client_Object(data1, data2, data3);
		//System.out.println("Sending values..." + API_Data.get_values() + "Sending API_Type" + API_Data.get_API_Type());
		return API_Data;
	}
}
