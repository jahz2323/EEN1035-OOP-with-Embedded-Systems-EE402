package Assignment_2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class ThreadedServer_Gui extends JFrame implements ActionListener {
	private JTextArea logArea;
	private List<String> connectedDevices;
	private List<Double> soundValues;
	private List<Double> tempValues;
	private List<Double> lightValues;
	private JList<String> sensorList;
	private String selectedSensor = "Sound";

	public ThreadedServer_Gui(ThreadedServer _server) {
		super("Server GUI");
		this.connectedDevices = new ArrayList<>();
		this.soundValues = new ArrayList<>();
		this.tempValues = new ArrayList<>();
		this.lightValues = new ArrayList<>();

		// Set up the main frame
		setLayout(new BorderLayout());
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Create panels for sound, temperature, and light
		JPanel soundPanel = createSensorPanel("Sound Level",
				"C:\\Users\\jahziel belmonte\\Downloads\\EEN1035-OOP-with-Embedded-Systems-EE402-main\\EEN1035-OOP-with-Embedded-Systems-EE402-main_OOP_Java\\src\\Assignment_2\\IMAGES\\audio-speaker-left-side-testing.255x256.png",
				soundValues);
		JPanel tempPanel = createSensorPanel("Temperature Level",
				"C:\\Users\\jahziel belmonte\\Downloads\\EEN1035-OOP-with-Embedded-Systems-EE402-main\\EEN1035-OOP-with-Embedded-Systems-EE402-main_OOP_Java\\src\\Assignment_2\\IMAGES\\temperature.png",
				tempValues);
		JPanel lightPanel = createSensorPanel("Light Level",
				"C:\\Users\\jahziel belmonte\\Downloads\\EEN1035-OOP-with-Embedded-Systems-EE402-main\\EEN1035-OOP-with-Embedded-Systems-EE402-main_OOP_Java\\src\\Assignment_2\\IMAGES\\lightbulb.256x244.png",
				lightValues);

		// Create a panel to hold the sensor panels
		JPanel sensorPanel = new JPanel(new GridLayout(1, 3));
		sensorPanel.add(soundPanel);
		sensorPanel.add(tempPanel);
		sensorPanel.add(lightPanel);

		// Create a log area
		logArea = new JTextArea(10, 50);
		logArea.setEditable(false);
		JScrollPane logScrollPane = new JScrollPane(logArea);

		// Create a JList for sensor selection
		DefaultListModel<String> listModel = new DefaultListModel<>();
		listModel.addElement("Sound Level");
		listModel.addElement("Temperature Level");
		listModel.addElement("Light Level");
		sensorList = new JList<>(listModel);
		sensorList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		sensorList.setSelectedIndex(0);
		sensorList.addListSelectionListener(e -> {
			if (!e.getValueIsAdjusting()) {
				selectedSensor = sensorList.getSelectedValue();
				logArea.append("Selected sensor: " + selectedSensor + "\n");
			}
		});

		// Add components to the main frame
		add(new JScrollPane(sensorList), BorderLayout.WEST);
		add(sensorPanel, BorderLayout.CENTER);
		add(logScrollPane, BorderLayout.SOUTH);

		// Add window listener to handle window close action
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				shutdownServer();
			}
		});

		setVisible(true);
	}

	private JPanel createSensorPanel(String sensorType, String imagePath, List<Double> values) {
		JPanel panel = new JPanel(new BorderLayout());
		JLabel label = new JLabel(sensorType, JLabel.CENTER);
		label.setFont(new Font("Arial", Font.BOLD, 16));

		// Load and display the image
		ImageIcon icon = new ImageIcon(imagePath);
		JLabel imageLabel = new JLabel(icon, JLabel.CENTER);

		// Create text fields for values
		JTextArea valueArea = new JTextArea(10, 20);
		valueArea.setEditable(false);

		// Create a custom gauge component
		GaugeComponent gauge = new GaugeComponent(values);

		// Add components to the panel
		panel.add(label, BorderLayout.NORTH);
		panel.add(imageLabel, BorderLayout.CENTER);
		panel.add(valueArea, BorderLayout.SOUTH);
		panel.add(gauge, BorderLayout.EAST);

		return panel;
	}

	private void shutdownServer() {
		// Implement server shutdown logic here
		System.out.println("Shutting down server...");
		// Close server resources and exit
		System.exit(0);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// Handle action events here
	}

	// Custom gauge component to display sensor readings
	class GaugeComponent extends JComponent {
		private List<Double> values;

		public GaugeComponent(List<Double> values) {
			this.values = values;
		}

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			if (values.isEmpty())
				return;

			double avg = values.stream().mapToDouble(Double::doubleValue).average().orElse(0);
			double min = values.stream().mapToDouble(Double::doubleValue).min().orElse(0);
			double max = values.stream().mapToDouble(Double::doubleValue).max().orElse(0);

			// Draw the gauge
			g.setColor(Color.BLACK);
			g.drawString("Avg: " + avg, 10, 20);
			g.drawString("Min: " + min, 10, 40);
			g.drawString("Max: " + max, 10, 60);
		}
	}

	// Method to update the GUI with new sensor data
	public void updateSensorData(String sensorType, double value) {
		// Only listen to selected GUI component @sensorList
		List<Double> values;
		switch (sensorType) {
		case "Sound Level":
			values = soundValues;
			System.out.println("Listening for " + sensorType);
			break;
		case "Temperature Level":
			values = tempValues;
			System.out.println("Listening for " + sensorType);
			break;
		case "Light Level":
			values = lightValues;
			System.out.println("Listening for " + sensorType);
			break;
		default:
			return;
		}

		// Add the new value and keep only the last 10 values
		values.add(value);
		if (values.size() > 10) {
			values.remove(0);
		}

		// Update the log area
		logArea.append(sensorType + " sensor value: " + value + "\n");

		// Repaint the gauge component
		repaint();
	}

	// Method to update the connection status of devices
	public void updateConnectionStatus(String deviceName, boolean connected) {
		if (connected) {
			connectedDevices.add(deviceName);
		} else {
			connectedDevices.remove(deviceName);
		}

		// Update the log area
		logArea.append("Device " + deviceName + " is " + (connected ? "connected" : "disconnected") + "\n");
	}

	public static void main(String[] args) {
//        // Create and start the server
//        ThreadedServer server = new ThreadedServer();
//        ThreadedServer_Gui gui = new ThreadedServer_Gui(server);
//        server.setGui(gui); // Pass the GUI reference to the server
//        new Thread(server).start();
	}
}