package Assignment_2;

import java.net.*;
import java.io.*;

public class ThreadedConnectionHandler extends Thread {
	private Socket clientSocket = null; // Client socket object
	private ObjectInputStream is = null; // Input stream
	private ObjectOutputStream os = null; // Output stream
	private ThreadedServer_Gui gui;

	// The constructor for the connection handler
	public ThreadedConnectionHandler(Socket clientSocket, ThreadedServer_Gui _gui) {
		this.clientSocket = clientSocket;
		this.gui = _gui;
	}
	public synchronized void run() {
		try {
			// Initialize input and output streams
			this.is = new ObjectInputStream(clientSocket.getInputStream());
			this.os = new ObjectOutputStream(clientSocket.getOutputStream());
			// Continuously read and process commands from the client
			while (this.readCommand()) {
			}
		} catch (IOException e) {
			System.out.println("XX. There was a problem with the Input/Output Communication:");
			e.printStackTrace();
		}
	}

	// Receive and process incoming string commands from client socket
	private synchronized boolean readCommand() {
		try {
//			Object s = is.readObject();
			Server_Client_Object Recieved_Message = (Server_Client_Object) is.readObject();
			Server_Client_Object Sent_Message;
			System.out.println("ThreadedConnectionHandler: API_Type is: " + Recieved_Message.get_API_Type());
			System.out.println("Values are " + Recieved_Message.get_values());
			/// Process the command based on the API_Type
			System.out.println(" ");
			System.out.println(" ");
			System.out.println("01. <- Received a Server_Client_Object object from the client (" + Recieved_Message + ").");
			System.out.println("With ServerIP: '" + Recieved_Message.get_Address() + "' Values: '"
					+ Recieved_Message.get_values() + "' API_Type: '" + Recieved_Message.get_API_Type());
			if (Recieved_Message.get_API_Type() != null) {
				switch (Recieved_Message.get_API_Type()) {
				case "Sound Level":
					// Handle Sound Level command
					gui.updateSensorData("Sound Level", Recieved_Message.get_values());
					break;
				case "Temperature Level":
					// Handle Temperature Level command
					gui.updateSensorData("Temperature Level", Recieved_Message.get_values());
					break;
				case "Light Level":
					// Handle Light Level command
					gui.updateSensorData("Light Level", Recieved_Message.get_values());
					break;
				}
			} else {
				System.out.println("Received message with null API_Type");	
			}
			// send back recieved message
			Sent_Message = Recieved_Message;
			send(Sent_Message);
			return true;
		} catch (Exception e) { // catch a general exception
			System.out.println("Error");
			this.closeSocket();
			return false;
		}
		
	}

	// Use our custom DateTimeService Class to get the date and time
	private synchronized void getDate() { // use the date service to get the date
		// String currentDateTimeText = theDateService.getDateAndTime();
		// this.send(currentDateTimeText);
	}

	// Send a generic object back to the client
	private synchronized void send(Object o) {
		
		try {
			System.out.println(" ");
			System.out.println(" ");
			System.out.println("02. -> Sending (" + o + ") to the client.");
			this.os.writeObject(o);
			this.os.flush();
		} catch (Exception e) {
			System.out.println("XX." + e.getStackTrace());
		}
	}

	// Send a pre-formatted error message to the client
	public void sendError(String message) {
		this.send("Error:" + message); // remember a String IS-A Object!
	}

	// Close the client socket
	public synchronized void closeSocket() { // gracefully close the socket connection
		try {
			this.os.close();
			this.is.close();
			this.clientSocket.close();
		} catch (Exception e) {
			System.out.println("XX. " + e.getStackTrace());
		}
	}
}